/**
 * Created by VannessTan on 11/04/2016.
 */

import java.util.Random;

public class Robot implements Runnable{

    private int[][] mapArray;
    private int newI = 0;
    private int newJ = 0;
    private int i, j, pickedX, pickedY;

    Random random = new Random();

    public Robot(int[][] mapArray){

        this.mapArray = mapArray;

        /*
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {

                if(i == 0 && j == 0){
                    mapArray[i][j] = 1;
                } else {
                    mapArray[i][j] = 0;
                }
            }
        }
        */
    }

    public void run(){

        mapArray[newI][newJ] = 1;

        while (true){

            i = newI;
            j = newJ;

            do{
                pickedX = (random.nextInt(3)) - 1;
                pickedY = (random.nextInt(3)) - 1;

            } while(pickedX == 0 && pickedY == 0);

            newI = newI + pickedX;
            newJ = newJ + pickedY;

            if(newI >= 0 && newI < mapArray.length && newJ >= 0 && newJ < mapArray.length){

                synchronized(mapArray){

                    mapArray[newI][newJ] = 1;
                    mapArray[i][j] = 0;
                }
            } else {

                newI = i;  newJ = j;
            }

            try{
                Thread.sleep(600);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

    }


    /*
        public int generateRandomNumber(){

        int pickedNumber = 0;

        Random random = new Random();
        pickedNumber = random.nextInt(4) + 1;

        return pickedNumber;
    }

        public synchronized void run(){

            while (true){

             int pickedNumber = generateRandomNumber();

                switch (pickedNumber){
                    case 1:
                        if(i == 7){
                            mapArray[i][j] = 1;
                        } else {
                            mapArray[i + 1][j] = 1;
                            mapArray[i][j] = 0;
                        }
                        break;

                    case 2:
                        if(j == 7){
                            mapArray[i][j] = 1;
                        } else {
                            mapArray[i][j + 1] = 1;
                            mapArray[i][j] = 0;
                        }
                        break;

                    case 3:
                        if (i == 0){
                            mapArray[i][j] = 1;
                        } else {
                            mapArray[i - 1][j] = 1;
                            mapArray[i][j] = 0;
                        }
                        break;

                    case 4:
                        if(j == 0){
                            mapArray[i][j] = 1;
                        } else {
                            mapArray[i][j - 1] = 1;
                            mapArray[i][j] = 0;
                        }
                        break;

                    default:
                        System.out.println("Picked number is out of range.");
                        break;

                }

                try {
                    Thread.sleep(600);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
     */


}
