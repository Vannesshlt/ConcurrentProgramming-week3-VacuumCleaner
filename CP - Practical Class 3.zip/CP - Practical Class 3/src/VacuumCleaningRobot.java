/**
 * Created by VannessTan on 11/04/2016.
 */

public class VacuumCleaningRobot {

    public static void main(String[] args) {

        int[][] mapArray = new int[8][8];

        Robot robotThread = new Robot(mapArray);
        Map mapThread = new Map(mapArray);

        Thread t1 = new Thread(robotThread);
        Thread t2 = new Thread(mapThread);

        t1.start();
        t2.start();


        try {
            t1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
