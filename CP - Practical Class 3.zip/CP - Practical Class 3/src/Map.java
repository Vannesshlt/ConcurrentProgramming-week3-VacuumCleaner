/**
 * Created by VannessTan on 12/04/2016.
 */

public class Map implements Runnable{

    private int[][] mapArray;
    private int i = 0;
    private int j = 0;

    public Map(int[][] mapArray){

        this.mapArray = mapArray;
    }
    public void run(){

        while (true){

            for (int i = 1; i <= 8; i++){
                for (int j = 1; j <= 8; j++){

                    System.out.printf("%2d", mapArray[i -1][j -1]);

                    if (j % 8 == 0){
                            System.out.println();
                    }
                }
            }

            System.out.println();

            try {
                Thread.sleep(600);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
